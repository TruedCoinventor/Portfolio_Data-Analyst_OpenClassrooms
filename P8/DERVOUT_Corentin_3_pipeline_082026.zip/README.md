# Pipeline DBT — Profil sociodémographique des étudiants Data OC (2022–2025)

Pipeline de transformation **DBT / Snowflake** qui prépare, fiabilise et enrichit
les inscriptions aux parcours Data d'OpenClassrooms, afin d'analyser l'évolution
du profil sociodémographique des étudiants (âge, genre, région) sur 4 ans.

---

## 1. Architecture (Bronze → Silver → Gold)

```
raw_data.ETUDIANTS ─┐
                    ├─► stg_etudiants ─────────┐
seeds INSEE :       │                          ├─► int_inscriptions_enrichies ─┬─► mart_demographie   (CSV livré)
  population        ├─► stg_insee__population ──┤                               └─► mart_synthese_region
  chomage           ├─► stg_insee__chomage ─────┘
  structure_age     └─► stg_insee__structure_age
   (Bronze/seeds)        (Silver / staging = vues)     (Silver / interm.)          (Gold / marts = tables)
```

| Couche | Rôle | Matérialisation |
|--------|------|-----------------|
| **Sources / Seeds** | Données brutes OC (Snowflake) + référentiels INSEE versionnés | table / seed |
| **Staging** | Nettoyage, standardisation, harmonisation des libellés | vue |
| **Intermediate** | Inscriptions enrichies du contexte régional INSEE | vue |
| **Marts** | Tables d'analyse agrégées (dont l'export CSV) | table |

## 2. Modèles

- **`stg_etudiants`** — nettoie les inscriptions : `GENDER` vide → `'Non renseigné'`,
  `trim` des libellés, harmonisation des régions via la macro `harmoniser_region`.
  Aucune déduplication : le grain reste l'**inscription** `(user_id, year_path_started)`.
- **`stg_insee__population` / `__chomage` / `__structure_age`** — mise en forme des
  référentiels INSEE chargés depuis les **seeds** (repo → pas de dépendance externe).
- **`int_inscriptions_enrichies`** — une ligne = une inscription + population et
  chômage de sa région.
- **`mart_demographie`** *(livrable CSV)* — comptages par
  `année × région × tranche d'âge × genre` + contexte INSEE.
- **`mart_synthese_region`** — pénétration régionale (**inscrits / 100 000 hab.**) et chômage.

## 3. Qualité — ~34 tests automatisés

Génériques (`not_null`, `unique`, `accepted_values`, `dbt_utils.accepted_range`,
`relationships`, `dbt_utils.unique_combination_of_columns`) **plus un test singulier
de réconciliation** (`tests/assert_reconciliation_inscriptions.sql`) qui vérifie que
`Σ nb_inscriptions (mart) == COUNT(*) (staging)` — donc qu'aucune ligne n'est perdue
ni dupliquée. Le test `relationships` sur `region` garantit que **chaque région OC a
une correspondance INSEE** (jointures fiables).

## 4. Conformité RGPD

- **Minimisation** : seules les variables utiles à l'analyse sont conservées.
- **Pseudonymisation** : `USER_ID` est un identifiant technique ; aucune donnée
  nominative (nom, e-mail) n'est présente ni introduite.
- **Agrégation** : les tables finales sont **agrégées** (comptages), sans ligne
  individuelle réidentifiable. Vigilance sur les petits effectifs (ex. DROM).
- **Traçabilité** : transformations versionnées (Git), documentées et testées.

## 5. Reproductibilité

```bash
dbt deps      # installe dbt_utils
dbt seed      # charge les référentiels INSEE
dbt run       # construit staging → intermediate → marts
dbt test      # exécute les ~34 tests
dbt docs generate && dbt docs serve   # documentation + lineage
```

`dbt run` est **idempotent** : à données d'entrée constantes, il reproduit
exactement les mêmes tables. Copier `profiles.yml.example` vers `~/.dbt/profiles.yml`
et renseigner la connexion Snowflake.

## 6. Limites connues

- **Genre non renseigné ~27 %**, très inégal dans le temps (42 % en 2022 → 7 % en
  2025) : l'analyse de genre est menée **hors NR** pour éviter un biais de tendance.
- **Région déclarée à l'inscription**, pas nécessairement de résidence.
- **14 % des étudiants** se réinscrivent sur plusieurs années (grain = inscription).
- Données INSEE = **valeurs de référence** (à réactualiser depuis insee.fr en prod).
- Pas de données de réussite / abandon dans ce périmètre.
