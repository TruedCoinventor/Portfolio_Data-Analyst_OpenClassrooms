-- Test de réconciliation : la somme des inscriptions du mart doit être
-- strictement égale au nombre de lignes nettoyées en staging.
-- Garantit qu'aucune ligne n'est perdue ou dupliquée par l'agrégation.
with controle as (
    select
        (select sum(nb_inscriptions) from {{ ref('mart_demographie') }}) as total_mart,
        (select count(*)             from {{ ref('stg_etudiants') }})    as total_staging
)
select *
from controle
where total_mart <> total_staging
