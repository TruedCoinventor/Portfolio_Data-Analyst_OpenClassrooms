-- Couche MARTS (Gold) : TABLE FINALE exportée en CSV.
-- Grain = année x région x tranche d'âge x genre.
-- Contient les comptages OC + le contexte INSEE (population, chômage).
with base as (
    select * from {{ ref('int_inscriptions_enrichies') }}
),

agrege as (
    select
        year_path_started,
        region,
        age_group,
        gender,
        count(*)                 as nb_inscriptions,
        count(distinct user_id)  as nb_etudiants_uniques,
        max(pop_region_2023)     as pop_region_2023,
        max(taux_chomage_2024)   as taux_chomage_2024,
        max(taux_chomage_2025)   as taux_chomage_2025
    from base
    group by 1, 2, 3, 4
)

select *
from agrege
order by year_path_started, region, age_group, gender
