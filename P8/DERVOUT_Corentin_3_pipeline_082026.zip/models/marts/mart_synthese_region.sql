-- MART d'analyse : synthèse par région sur l'ensemble de la période.
-- Calcule l'indicateur de pénétration (inscrits pour 100 000 habitants)
-- et rapproche du taux de chômage régional.
with base as (
    select * from {{ ref('int_inscriptions_enrichies') }}
),

par_region as (
    select
        region,
        count(*)                as nb_inscriptions,
        count(distinct user_id) as nb_etudiants_uniques,
        max(pop_region_2023)    as pop_region_2023,
        max(taux_chomage_2024)  as taux_chomage_2024
    from base
    group by 1
)

select
    region,
    nb_inscriptions,
    nb_etudiants_uniques,
    pop_region_2023,
    round(nb_inscriptions * 100000.0 / pop_region_2023, 1) as inscrits_pour_100k,
    taux_chomage_2024
from par_region
order by nb_inscriptions desc
