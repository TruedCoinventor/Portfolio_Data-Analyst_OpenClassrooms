-- Couche INTERMEDIATE : inscriptions nettoyées + contexte régional INSEE.
-- Une ligne = une inscription, enrichie de sa population et de son chômage
-- régional. Sert de socle unique aux marts d'agrégation.
with etudiants as (
    select * from {{ ref('stg_etudiants') }}
),
population as (
    select * from {{ ref('stg_insee__population') }}
),
chomage as (
    select * from {{ ref('stg_insee__chomage') }}
)

select
    e.user_id,
    e.year_path_started,
    e.region,
    e.age_group,
    e.gender,
    p.population_2023      as pop_region_2023,
    c.taux_chomage_2024,
    c.taux_chomage_2025
from etudiants e
left join population p on e.region = p.region
left join chomage    c on e.region = c.region
