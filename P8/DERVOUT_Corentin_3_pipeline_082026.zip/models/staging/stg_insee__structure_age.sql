-- STAGING référentiel INSEE : structure par grande tranche d'âge de la
-- population française (référence pour comparer le profil OC à la France).
with source as (
    select * from {{ ref('insee_structure_age_nationale') }}
)

select
    trim(age_group)                     as age_group,
    cast(part_population_fr_pct as float) as part_population_fr_pct
from source
