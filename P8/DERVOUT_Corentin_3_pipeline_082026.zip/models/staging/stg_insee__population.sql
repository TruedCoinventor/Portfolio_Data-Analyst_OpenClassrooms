-- STAGING référentiel INSEE : population régionale (estimations 2023).
-- Chargé depuis un seed versionné => reproductible sans dépendance externe.
with source as (
    select * from {{ ref('insee_population_regionale') }}
)

select
    {{ harmoniser_region('region') }} as region,
    cast(population_2023 as integer)  as population_2023
from source
