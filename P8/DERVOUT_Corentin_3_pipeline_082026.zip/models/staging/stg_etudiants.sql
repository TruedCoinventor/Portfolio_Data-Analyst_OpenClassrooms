-- Couche STAGING (Silver) : nettoyage & standardisation des inscriptions OC.
-- Choix documentés :
--   * GENDER vide -> 'Non renseigné' (on conserve la ligne : le NR est une
--     information en soi, il représente ~27% des lignes et décroît fortement
--     dans le temps ; le supprimer biaiserait les volumes).
--   * REGION harmonisée via la macro (jointures INSEE fiables).
--   * On NE déduplique PAS : le grain est l'inscription. 14% des étudiants se
--     réinscrivent sur plusieurs années ; ces lignes sont des événements réels.
with source as (
    select * from {{ source('raw_data', 'ETUDIANTS') }}
),

cleaned as (
    select
        trim(user_id)                                   as user_id,
        trim(path_category_name)                        as path_category_name,
        trim(age_group)                                 as age_group,
        case
            when gender is null or trim(gender) = '' then 'Non renseigné'
            else trim(gender)
        end                                             as gender,
        {{ harmoniser_region('region') }}               as region,
        cast(year_path_started as integer)              as year_path_started
    from source
)

select * from cleaned
