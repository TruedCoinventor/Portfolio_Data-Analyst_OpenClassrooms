-- STAGING référentiel INSEE : taux de chômage localisé par région (T3).
with source as (
    select * from {{ ref('insee_chomage_regional') }}
)

select
    {{ harmoniser_region('region') }} as region,
    cast(taux_chomage_2024 as float)  as taux_chomage_2024,
    cast(taux_chomage_2025 as float)  as taux_chomage_2025
from source
