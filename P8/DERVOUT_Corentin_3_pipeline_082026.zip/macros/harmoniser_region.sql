{#
    Harmonise les libelles de region pour fiabiliser les jointures entre
    les donnees OC et les referentiels INSEE.
    Ici : suppression des espaces superflus (trim). Les libelles OC et INSEE
    sont deja alignes, donc aucun remappage n'est necessaire.
    Rappel SQL : une chaine litterale se met entre guillemets SIMPLES ;
    les guillemets doubles designent un identifiant (nom de colonne).
#}
{% macro harmoniser_region(colonne) %}
    trim({{ colonne }})
{% endmacro %}